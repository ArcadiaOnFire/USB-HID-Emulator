#include <jni.h>
#include <fcntl.h>
#include <unistd.h>
#include <string.h>

JNIEXPORT jint JNICALL
Java_com_example_usbhidemulator_MainActivity_writeHidReport(JNIEnv *env, jobject thiz, jstring path, jbyteArray report) {
    const char *device_path = (*env)->GetStringUTFChars(env, path, 0);
    jbyte *buf = (*env)->GetByteArrayElements(env, report, 0);
    jsize len = (*env)->GetArrayLength(env, report);

    int fd = open(device_path, O_WRONLY);
    if (fd < 0) {
        (*env)->ReleaseStringUTFChars(env, path, device_path);
        (*env)->ReleaseByteArrayElements(env, report, buf, 0);
        return -1; // failed to open
    }

    ssize_t written = write(fd, buf, len);
    close(fd);

    (*env)->ReleaseStringUTFChars(env, path, device_path);
    (*env)->ReleaseByteArrayElements(env, report, buf, 0);

    return (int)written; // number of bytes written or error
}
