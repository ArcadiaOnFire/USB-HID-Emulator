package com.example.usbhidemulator;

import android.Manifest;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.view.View;
import android.widget.Button;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class MainActivity extends AppCompatActivity {

    private static final String LOG_FILE_NAME = "usb_hid_emulator_log.txt";
    private static final int REQUEST_CODE_WRITE_STORAGE = 1001;

    private File logFile = null;
    private Process rootProcess = null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // Set layout
        setContentView(R.layout.activity_main);

        // Request storage permission on API <= 28
        if (Build.VERSION.SDK_INT <= Build.VERSION_CODES.P) {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.WRITE_EXTERNAL_STORAGE)
                    != PackageManager.PERMISSION_GRANTED) {
                ActivityCompat.requestPermissions(this,
                        new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE},
                        REQUEST_CODE_WRITE_STORAGE);
            } else {
                initializeLoggingAndRoot();
            }
        } else {
            // On API 29+, proceed without requesting WRITE_EXTERNAL_STORAGE (write to app-specific folder)
            initializeLoggingAndRoot();
        }

        // Setup buttons with listeners (IDs must match your layout)
        setupButton(R.id.buttonDirectKeyboard, "Direct Keyboard", () -> runRootCommand("id"));
        setupButton(R.id.buttonLeftClick, "Left Mouse Click", () -> runRootCommand("echo Left click simulated"));
        setupButton(R.id.buttonMiddleClick, "Middle Mouse Click", () -> runRootCommand("echo Middle click simulated"));
        setupButton(R.id.buttonRightClick, "Right Mouse Click", () -> runRootCommand("echo Right click simulated"));
    }

    private void initializeLoggingAndRoot() {
        prepareLogFile();
        logToFile("App started.");
        requestRootShell();
    }

    private void prepareLogFile() {
        try {
            File docsFolder;
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                // For API 29+, write inside app-specific Documents folder (no permission needed)
                docsFolder = getExternalFilesDir(Environment.DIRECTORY_DOCUMENTS);
            } else {
                // For API <= 28, write to public Documents folder (permission needed)
                docsFolder = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOCUMENTS);
            }

            if (docsFolder == null) {
                // Defensive: should never be null but log just in case
                return;
            }

            if (!docsFolder.exists() && !docsFolder.mkdirs()) {
                // Failed to create dir
                return;
            }

            logFile = new File(docsFolder, LOG_FILE_NAME);
            logToFile("Logging initialized. Log file path: " + logFile.getAbsolutePath());
        } catch (Exception e) {
            // Swallow exceptions here but ideally notify/log somewhere
        }
    }

    private void requestRootShell() {
        try {
            rootProcess = Runtime.getRuntime().exec("su");
            if (rootProcess.isAlive()) {
                logToFile("Root shell obtained.");
            } else {
                logToFile("Root shell NOT obtained.");
            }
        } catch (IOException e) {
            logToFile("IOException requesting root shell: " + e.getMessage());
        }
    }

    private void runRootCommand(String command) {
        logToFile("Running root command: " + command);
        if (rootProcess == null || !rootProcess.isAlive()) {
            logToFile("Root shell not available.");
            return;
        }

        try {
            rootProcess.getOutputStream().write((command + "\n").getBytes());
            rootProcess.getOutputStream().flush();

            // Read output for max 1 second
            BufferedReader reader = new BufferedReader(new InputStreamReader(rootProcess.getInputStream()));
            StringBuilder output = new StringBuilder();
            long start = System.currentTimeMillis();
            String line;
            while (System.currentTimeMillis() - start < 1000) {
                if (reader.ready() && (line = reader.readLine()) != null) {
                    output.append(line).append("\n");
                } else {
                    break;
                }
            }
            String outStr = output.toString().trim();
            if (outStr.isEmpty()) outStr = "(no output)";
            logToFile("Root command output: " + outStr);
        } catch (IOException e) {
            logToFile("IOException during root command: " + e.getMessage());
        }
    }

    private void setupButton(int buttonId, String name, Runnable action) {
        View button = findViewById(buttonId);
        if (button == null) {
            logToFile("Button with ID " + buttonId + " (" + name + ") NOT found in layout.");
            return;
        }
        button.setOnClickListener(v -> {
            logToFile(name + " button pressed.");
            action.run();
        });
    }

    private void logToFile(String message) {
        if (logFile == null) {
            // Can't log to file if not initialized; just skip
            return;
        }
        try (FileWriter writer = new FileWriter(logFile, true)) {
            String timestamp = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS", Locale.US).format(new Date());
            writer.append(timestamp).append(": ").append(message).append("\n");
        } catch (IOException ignored) {
            // Don't crash app if logging fails
        }
    }

    // Handle permission result to start logging if permission granted
    @Override
    public void onRequestPermissionsResult(int requestCode,
                                           @NonNull String[] permissions,
                                           @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQUEST_CODE_WRITE_STORAGE) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                initializeLoggingAndRoot();
            } else {
                // Permission denied, but we proceed without external storage logs
                logToFile("Write external storage permission denied.");
            }
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (rootProcess != null) {
            rootProcess.destroy();
            logToFile("Root shell destroyed.");
        }
        logToFile("App destroyed.");
    }
}
